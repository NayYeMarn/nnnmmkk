package com.nayyemarn.app;

import android.app.*;
import android.content.*;
import android.net.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;

public class MainActivity extends Activity {
	Button btn,about,deve;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		btn=(Button)findViewById(R.id.btn);
		about=(Button)findViewById(R.id.about);
		deve = (Button)findViewById(R.id.deve);
		btn.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					Intent i=new Intent(getApplicationContext(),Two.class);
					startActivity(i);
				}});
				
				about.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					Intent i=new Intent(getApplicationContext(),ABOUT.class);
					startActivity(i);
				}});
				

		deve.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					Intent i=new Intent(getApplicationContext(),DEVELOPER.class);
					startActivity(i);
				}});}}
				
	
				

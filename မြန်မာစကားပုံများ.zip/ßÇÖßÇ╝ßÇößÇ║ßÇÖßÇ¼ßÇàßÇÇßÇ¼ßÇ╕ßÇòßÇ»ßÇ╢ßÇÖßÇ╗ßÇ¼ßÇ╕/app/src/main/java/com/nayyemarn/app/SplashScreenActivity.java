package com.nayyemarn.app;

import java.util.Timer;
import java.util.TimerTask;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Window;

public class SplashScreenActivity extends Activity {

	long Delay = 5000;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.splash_screen);

		Timer RunSplash = new Timer();

		TimerTask ShowSplash = new TimerTask() {
			@Override
			public void run() {
				finish();
				Intent myIntent = new Intent(SplashScreenActivity.this,
											 MainActivity.class);
				startActivity(myIntent);
			}
		};
		RunSplash.schedule(ShowSplash, Delay);
	}
}

package com.nayyemarn.app;
import android.app.*;
import android.content.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;

public class Two extends Activity
{
Button b1,b2,b3,b4,b5,b6,b7,b8,b9,b10,b11,b12,b13,b14,b15,b16,b17,b18,b19,b20,b21;
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		// TODO: Implement this method
		super.onCreate(savedInstanceState);
		setContentView(R.layout.two);
		b1=(Button)findViewById(R.id.b1);
		b2=(Button)findViewById(R.id.b2);
		b3=(Button)findViewById(R.id.b3);
		b4=(Button)findViewById(R.id.b4);
		b5=(Button)findViewById(R.id.b5);
		b6=(Button)findViewById(R.id.b6);
		b7=(Button)findViewById(R.id.b7);
		b8=(Button)findViewById(R.id.b8);
		b9=(Button)findViewById(R.id.b9);
		b10=(Button)findViewById(R.id.b10);
		b11=(Button)findViewById(R.id.b11);
		b12=(Button)findViewById(R.id.b12);
		b13=(Button)findViewById(R.id.b13);
		b14=(Button)findViewById(R.id.b14);
		b15=(Button)findViewById(R.id.b15);
		b16=(Button)findViewById(R.id.b16);
		b17=(Button)findViewById(R.id.b17);
		b18=(Button)findViewById(R.id.b18);
		b19=(Button)findViewById(R.id.b19);
		b20=(Button)findViewById(R.id.b20);
		b21=(Button)findViewById(R.id.b21);
		
		b1.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					Intent i=new Intent(getApplicationContext(),KA.class);
					startActivity(i);
				}});
				
		b2.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					Intent i=new Intent(getApplicationContext(),KHA.class);
					startActivity(i);
				}});
				
		b3.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					Intent i=new Intent(getApplicationContext(),GA.class);
					startActivity(i);
				}});

		b4.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					Intent i=new Intent(getApplicationContext(),SA.class);
					startActivity(i);
				}});
				
		b5.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					Intent i=new Intent(getApplicationContext(),SALEIN.class);
					startActivity(i);
				}});
				
		b6.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					Intent i=new Intent(getApplicationContext(),NYA.class);
					startActivity(i);
				}});
		
		b7.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					Intent i=new Intent(getApplicationContext(),TA.class);
					startActivity(i);
				}});
				
		b8.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					Intent i=new Intent(getApplicationContext(),HTA.class);
					startActivity(i);
				}});
				
		b9.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					Intent i=new Intent(getApplicationContext(),NA.class);
					startActivity(i);
				}});
				
		b10.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					Intent i=new Intent(getApplicationContext(),PA.class);
					startActivity(i);
				}});
				
		b11.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					Intent i=new Intent(getApplicationContext(),PHA.class);
					startActivity(i);
				}});
				
		b12.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					Intent i=new Intent(getApplicationContext(),BA.class);
					startActivity(i);
				}});
		
		b13.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					Intent i=new Intent(getApplicationContext(),MA.class);
					startActivity(i);
				}});
		
		b14.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					Intent i=new Intent(getApplicationContext(),YAPA.class);
					startActivity(i);
				}});
		
		b15.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					Intent i=new Intent(getApplicationContext(),YAKA.class);
					startActivity(i);
				}});
		
		b16.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					Intent i=new Intent(getApplicationContext(),LA.class);
					startActivity(i);
				}});
		
		b17.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					Intent i=new Intent(getApplicationContext(),WA.class);
					startActivity(i);
				}});
		
		b18.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					Intent i=new Intent(getApplicationContext(),THA.class);
					startActivity(i);
				}});
		
		b19.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					Intent i=new Intent(getApplicationContext(),HA.class);
					startActivity(i);
				}});
		
		b20.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					Intent i=new Intent(getApplicationContext(),LAGYI.class);
					startActivity(i);
				}});
		
		b21.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					Intent i=new Intent(getApplicationContext(),AH.class);
					startActivity(i);
				}});
				}
	
}

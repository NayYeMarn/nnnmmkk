package com.nayyemarn.app;

import android.app.*;
import android.content.*;
import android.net.*;
import android.os.*;
import android.view.*;
import android.widget.*;

public class DEVELOPER extends Activity
{
private Button downloadBtn;
Button sub;


	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		// TODO: Implement this method
		super.onCreate(savedInstanceState);
		setContentView(R.layout.developer);
		
		
	downloadBtn =findViewById(R.id.mainButton);

	downloadBtn.setOnClickListener(new View.OnClickListener()
	{
	@Override
	public void onClick(View view){



		Intent intent = new Intent();
		intent.setAction(Intent.ACTION_VIEW);
		intent.addCategory(Intent.CATEGORY_BROWSABLE);
		intent.setData(Uri.parse("https://www.instagram.com/nay_ye_marn_007/"));
		startActivity(intent);

	}


		});		
		sub=findViewById(R.id.sub);

				sub.setOnClickListener(new View.OnClickListener()
				{
				@Override
				public void onClick(View view){



					Intent intent = new Intent();
					intent.setAction(Intent.ACTION_VIEW);
					intent.addCategory(Intent.CATEGORY_BROWSABLE);
					intent.setData(Uri.parse("https://www.youtube.com/channel/UCZvravgDT6kunCr2l8zF1vQ"));
					startActivity(intent);

				}
				

	});}

	public void myFacebook (View myView) {

		String myFacebookId = "100011670754214"; 
		startActivity(NayYeMarn(this,"fb://profile/" + myFacebookId, "https://mobile.facebook.com/profile.php?id=" + myFacebookId));
		this.startActivity(this.NayYeMarn(this, "fb://profile/" + myFacebookId, "https://mobile.facebook.com/profile.php?id=" + myFacebookId));
	}
	public static Intent NayYeMarn (Context context, String wordsID, String wordID) {
        try {
            context.getPackageManager().getPackageInfo("com.facebook.katana", 0);
            Intent goF = new Intent("android.intent.action.VIEW", Uri.parse(wordsID));
            return goF;
        } catch (Exception e) {
            Intent goF = new Intent("android.intent.action.VIEW", Uri.parse(wordID));
            return goF;
        } 
	}}
	

	
